package com.lukecherochak.handson8;

public interface Mammal extends Animal {
void speak();
void run();
void eat();
}
