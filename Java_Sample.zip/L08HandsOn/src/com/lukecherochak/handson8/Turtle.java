package com.lukecherochak.handson8;

public class Turtle implements Reptile {

	@Override
	public void eat() {
		// TODO Auto-generated method stub
		System.out.println("Tutles eat the lettuce.");
	}

	@Override
	public void crawl() {
		// TODO Auto-generated method stub
		System.out.println("Turtles crawl slow");
	}

}
