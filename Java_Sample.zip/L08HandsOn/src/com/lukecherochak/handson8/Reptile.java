package com.lukecherochak.handson8;

public interface Reptile extends Animal {
void crawl();
}
