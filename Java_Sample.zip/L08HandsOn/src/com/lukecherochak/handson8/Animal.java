package com.lukecherochak.handson8;

public interface Animal {
void eat();

}
