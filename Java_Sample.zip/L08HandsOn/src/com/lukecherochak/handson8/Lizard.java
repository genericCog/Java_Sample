package com.lukecherochak.handson8;

public class Lizard implements Reptile{

	@Override
	public void eat() {
		// TODO Auto-generated method stub
		System.out.println("Lizards eat crickets.");
	}

	@Override
	public void crawl() {
		// TODO Auto-generated method stub
		System.out.println("Lizards crawl fast.");
	}

}
