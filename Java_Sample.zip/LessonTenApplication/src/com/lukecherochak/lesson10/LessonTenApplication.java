package com.lukecherochak.lesson10;

import java.util.ArrayList;
import java.util.Scanner;

public class LessonTenApplication {
	
	//list of tasks = arrayList?
	static ArrayList<Task> tasks;
	//read from console
	static Scanner sc;
	
	public static void main(String[] args) {
		
		//initialize my arrayList
		tasks = new ArrayList<Task>();
		//initialize the scanner
		sc = new Scanner(System.in);
		
		tasks.add(new Task("Work"));
		tasks.add(new Task("School"));
		tasks.add(new Task("Mandatory Overtime"));
		tasks.add(new Task("School"));
		tasks.add(new Task("Graduate"));
		tasks.add(new Task("Live the dream!"));
		
		boolean running = true;
		
		do {
			displayMenu();		
			int menuChoice = readChoice();
			
			switch(menuChoice) {
				case 1:
					System.out.println("Name of the task to add:");
					String taskName = sc.nextLine();
					addTask(taskName);
					break;
				case 2:
					listTasks();
					System.out.println("Task to remove:");
					int removeId = readChoice();
					removeTask(removeId);
					break;
				case 3:
					listTasks();
					System.out.println("Task to complete:");
					int completeId = readChoice();
					completeTask(completeId);
					break;
				case 4:
					listTasks();
					break;
				case 0:
					running = false;
					break;
					default:
						System.out.println("Unknown menu choice.");
				
			}
			
		//running = false;
		} while(running);		
				
	
		
	}
	
	public static void displayMenu() {
		System.out.println("<Task Manager>");
		System.out.println("1: Add a task.");
		System.out.println("2: Remove a task.");
		System.out.println("3: Mark a task complete.");
		System.out.println("4: List the tasks.");
		System.out.println("0: Quit.");
		System.out.println("Choice:");
}
	
	public static int readChoice() {
		int result = sc.nextInt();
		sc.nextLine();
		return result;
	}
	
	public static void listTasks() {
		System.out.println("<Tasks>");
		for(int i = 0; i < tasks.size(); i++) {
			System.out.println(i+1 +". " + tasks.get(i).toString());
		}
	}
	
	public static void completeTask(int id ) {
		tasks.get(id-1).setComplete(true);
	}
	
	public static void removeTask(int id) {
		tasks.remove(id-1);
	}
	
	public static void addTask(String name) {
		tasks.add(new Task(name));
	}
	
}
